## Step to run the project

### 1. Please make sure that you already have [Node.js](https://nodejs.org/en/download/) installed in your local machine

### 2. `npm install` or `npm i`
Install libraries and dependencies.
### 3. `npm start`
Start the project.
