import React from 'react'
import './OrderIconTrackFilled.css'
import ImgAsset from '../public'
export default function OrderIconTrackFilled (props) {
	return (
		<div className={`OrderIconTrackFilled_OrderIconTrackFilled ${props.className}`}>
			<img className='Subtract' src = {ImgAsset.OrderIconTrackFilled_Subtract} />
		</div>
	)
}