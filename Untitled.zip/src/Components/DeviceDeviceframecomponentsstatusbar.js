import React from 'react'
import './DeviceDeviceframecomponentsstatusbar.css'
export default function DeviceDeviceframecomponentsstatusbar (props) {
	return (
		<div className={`DeviceDeviceframecomponentsstatusbar_DeviceDeviceframecomponentsstatusbar ${props.className}`}>
		</div>
	)
}