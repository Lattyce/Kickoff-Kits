import React from 'react'
import './MinusCircle.css'
import ImgAsset from '../public'
export default function MinusCircle (props) {
	return (
		<div className={`MinusCircle_MinusCircle ${props.className}`}>
			<img className='Vector' src = {ImgAsset.MinusCircle_Vector} />
		</div>
	)
}