import React from 'react'
import './Heart_2.css'
import ImgAsset from '../public'
export default function Heart_2 (props) {
	return (
		<div className={`Heart_2_Heart ${props.className}`}>
			<img className='Vector' src = {ImgAsset.Heart_2_Vector} />
		</div>
	)
}