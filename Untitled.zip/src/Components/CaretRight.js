import React from 'react'
import './CaretRight.css'
import ImgAsset from '../public'
export default function CaretRight (props) {
	return (
		<div className={`CaretRight_CaretRight ${props.className}`}>
			<img className='Vector' src = {ImgAsset.CaretRight_Vector} />
		</div>
	)
}