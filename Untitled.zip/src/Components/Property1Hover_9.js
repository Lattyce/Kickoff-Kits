import React from 'react'
import './Property1Hover_9.css'
import ShoppingCart_1 from "./ShoppingCart_1"
export default function Property1Hover_9 (props) {
	return (
		<div className={`Property1Hover_9_Property1Hover ${props.className}`}>
			<ShoppingCart_1 className='ShoppingCart'/>
		</div>
	)
}