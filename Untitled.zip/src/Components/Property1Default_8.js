import React from 'react'
import './Property1Default_8.css'
import Heart from "./Heart"
export default function Property1Default_8 (props) {
	return (
		<div className={`Property1Default_8_Property1Default ${props.className}`}>
			<Heart className='Heart'/>
		</div>
	)
}