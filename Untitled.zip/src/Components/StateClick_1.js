import React from 'react'
import './StateClick_1.css'
import ButtonMain from "./ButtonMain"
export default function StateClick_1 (props) {
	return (
		<div className={`StateClick_1_StateClick ${props.className}`}>
			<ButtonMain className='ButtonMain'/>
		</div>
	)
}