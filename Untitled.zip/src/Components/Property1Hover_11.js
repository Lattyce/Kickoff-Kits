import React from 'react'
import './Property1Hover_11.css'
export default function Property1Hover_11 (props) {
	return (
		<div className={`Property1Hover_11_Property1Hover ${props.className}`}>
			<span className='ShopNow'>Shop Now</span>
		</div>
	)
}