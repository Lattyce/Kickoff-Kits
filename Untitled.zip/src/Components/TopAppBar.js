import React from 'react'
import './TopAppBar.css'
import {Link} from 'react-router-dom'
import MagnifyingGlass from "./MagnifyingGlass"
import BellSimple from "./BellSimple"
import ShoppingCart from "./ShoppingCart"
export default function TopAppBar (props) {
	return (
		<div className={`TopAppBar_TopAppBar ${props.className}`}>
			<div className='HeroNavBar'>
				<div className='Frame66'>
					<span className='Searchforanything'>Search for anything</span>
					<MagnifyingGlass className='MagnifyingGlass'/>
				</div>
				<div className='Frame13'>
					<span className='Searchforanything_1'>Search for anything</span>
					<MagnifyingGlass className='MagnifyingGlass_1'/>
				</div>
				<div className='Frame65'>
					<div className='Frame66_1'>
						<BellSimple className='BellSimple'/>
					</div>
					<Link to='/undefined'>
						<div className='Frame17'>
							<ShoppingCart className='ShoppingCart'/>
							<div className='CartContentIndicator'>
								<span className='_4'>4</span>
							</div>
						</div>
					</Link>
				</div>
			</div>
		</div>
	)
}