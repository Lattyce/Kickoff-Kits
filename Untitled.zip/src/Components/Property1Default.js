import React from 'react'
import './Property1Default.css'
export default function Property1Default (props) {
	return (
		<div className={`Property1Default_Property1Default ${props.className}`}>
			<span className='ShopNow'>Shop Now</span>
		</div>
	)
}