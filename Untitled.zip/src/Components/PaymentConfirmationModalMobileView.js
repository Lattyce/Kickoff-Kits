import React from 'react'
import './PaymentConfirmationModalMobileView.css'
import ImgAsset from '../public'
import {Link} from 'react-router-dom'
import Property1Default from "./Property1Default"
export default function PaymentConfirmationModalMobileView (props) {
	return (
		<div className={`PaymentConfirmationModalMobileView_PaymentConfirmationModalMobileView ${props.className}`}>
			<div className='packagecheckingdeliverysvgrepocom1'>
				<img className='Vector' src = {ImgAsset.PaymentConfirmationModalMobileView_Vector} />
				<img className='Vector_1' src = {ImgAsset.PaymentConfirmationModalMobileView_Vector_1} />
				<img className='Vector_2' src = {ImgAsset.PaymentConfirmationModalMobileView_Vector_2} />
				<img className='Vector_3' src = {ImgAsset.PaymentConfirmationModalMobileView_Vector_3} />
				<img className='Vector_4' src = {ImgAsset.PaymentConfirmationModalMobileView_Vector_4} />
				<div className='Group'>
					<img className='Vector_5' src = {ImgAsset.PaymentConfirmationModalMobileView_Vector_5} />
					<img className='Vector_6' src = {ImgAsset.PaymentConfirmationModalMobileView_Vector_6} />
				</div>
				<img className='Vector_7' src = {ImgAsset.PaymentConfirmationModalMobileView_Vector_7} />
				<img className='Vector_8' src = {ImgAsset.PaymentConfirmationModalMobileView_Vector_8} />
				<img className='Vector_9' src = {ImgAsset.PaymentConfirmationModalMobileView_Vector_9} />
				<img className='Vector_10' src = {ImgAsset.PaymentConfirmationModalMobileView_Vector_10} />
				<img className='Vector_11' src = {ImgAsset.PaymentConfirmationModalMobileView_Vector_11} />
				<img className='Vector_12' src = {ImgAsset.PaymentConfirmationModalMobileView_Vector_12} />
				<img className='Vector_13' src = {ImgAsset.PaymentConfirmationModalMobileView_Vector_13} />
				<img className='Vector_14' src = {ImgAsset.PaymentConfirmationModalMobileView_Vector_14} />
				<img className='Vector_15' src = {ImgAsset.PaymentConfirmationModalMobileView_Vector_15} />
				<img className='Vector_16' src = {ImgAsset.PaymentConfirmationModalMobileView_Vector_16} />
				<img className='Vector_17' src = {ImgAsset.PaymentConfirmationModalMobileView_Vector_17} />
				<img className='Vector_18' src = {ImgAsset.PaymentConfirmationModalMobileView_Vector_18} />
				<img className='Vector_19' src = {ImgAsset.PaymentConfirmationModalMobileView_Vector_19} />
				<img className='Vector_20' src = {ImgAsset.PaymentConfirmationModalMobileView_Vector_20} />
				<img className='Vector_21' src = {ImgAsset.PaymentConfirmationModalMobileView_Vector_21} />
				<img className='Vector_22' src = {ImgAsset.PaymentConfirmationModalMobileView_Vector_22} />
				<img className='Vector_23' src = {ImgAsset.PaymentConfirmationModalMobileView_Vector_23} />
			</div>
			<div className='Frame39891'>
				<div className='Frame39890'>
					<span className='PaymentSuccessful'>Payment Successful</span>
					<span className='Yourorderisbeingprocessedandyouwillreceiveamailwithdetails'>Your order is being processed and you will receive a mail with details.</span>
				</div>
				<Property1Default className='CheckoutButton'/>
			</div>
		</div>
	)
}