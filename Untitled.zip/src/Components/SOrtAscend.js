import React from 'react'
import './SOrtAscend.css'
import ImgAsset from '../public'
export default function SOrtAscend (props) {
	return (
		<div className={`SOrtAscend_SOrtAscend ${props.className}`}>
			<div className='elements'>
				<img className='Vector6931' src = {ImgAsset.SOrtAscend_Vector6931} />
			</div>
		</div>
	)
}