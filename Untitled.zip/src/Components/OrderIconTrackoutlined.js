import React from 'react'
import './OrderIconTrackoutlined.css'
import ImgAsset from '../public'
export default function OrderIconTrackoutlined (props) {
	return (
		<div className={`OrderIconTrackoutlined_OrderIconTrackoutlined ${props.className}`}>
			<img className='Vector' src = {ImgAsset.OrderIconTrackoutlined_Vector} />
			<img className='Vector_1' src = {ImgAsset.OrderIconTrackoutlined_Vector_1} />
			<img className='Vector_2' src = {ImgAsset.OrderIconTrackoutlined_Vector_2} />
			<img className='Vector_3' src = {ImgAsset.OrderIconTrackoutlined_Vector_3} />
			<div className='Group1'>
				<img className='Vector_4' src = {ImgAsset.OrderIconTrackoutlined_Vector_4} />
				<img className='Vector_5' src = {ImgAsset.OrderIconTrackoutlined_Vector_5} />
			</div>
		</div>
	)
}