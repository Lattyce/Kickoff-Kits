import React from 'react'
import './FunnelSimple.css'
import ImgAsset from '../public'
export default function FunnelSimple (props) {
	return (
		<div className={`FunnelSimple_FunnelSimple ${props.className}`}>
			<img className='Vector' src = {ImgAsset.FunnelSimple_Vector} />
		</div>
	)
}