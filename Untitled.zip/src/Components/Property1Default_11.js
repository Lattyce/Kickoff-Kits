import React from 'react'
import './Property1Default_11.css'
import Heart from "./Heart"
export default function Property1Default_11 (props) {
	return (
		<div className={`Property1Default_11_Property1Default ${props.className}`}>
			<Heart className='Heart'/>
		</div>
	)
}