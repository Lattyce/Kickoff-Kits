import React from 'react'
import './StateHover_1.css'
import ButtonMain from "./ButtonMain"
export default function StateHover_1 (props) {
	return (
		<div className={`StateHover_1_StateHover ${props.className}`}>
			<ButtonMain className='ButtonMain'/>
		</div>
	)
}