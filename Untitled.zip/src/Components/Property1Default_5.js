import React from 'react'
import './Property1Default_5.css'
import Heart from "./Heart"
export default function Property1Default_5 (props) {
	return (
		<div className={`Property1Default_5_Property1Default ${props.className}`}>
			<Heart className='Heart'/>
		</div>
	)
}