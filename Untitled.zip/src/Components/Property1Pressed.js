import React from 'react'
import './Property1Pressed.css'
export default function Property1Pressed (props) {
	return (
		<div className={`Property1Pressed_Property1Pressed ${props.className}`}>
			<span className='ShopNow'>Shop Now</span>
		</div>
	)
}