import React from 'react'
import './Property1Default_3.css'
import ShoppingCart_1 from "./ShoppingCart_1"
export default function Property1Default_3 (props) {
	return (
		<div className={`Property1Default_3_Property1Default ${props.className}`}>
			<ShoppingCart_1 className='ShoppingCart'/>
		</div>
	)
}