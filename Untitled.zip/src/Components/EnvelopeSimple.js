import React from 'react'
import './EnvelopeSimple.css'
import ImgAsset from '../public'
export default function EnvelopeSimple (props) {
	return (
		<div className={`EnvelopeSimple_EnvelopeSimple ${props.className}`}>
			<img className='Vector' src = {ImgAsset.EnvelopeSimple_Vector} />
		</div>
	)
}