import React from 'react'
import './DeviceDeviceframecomponentsnavigation.css'
export default function DeviceDeviceframecomponentsnavigation (props) {
	return (
		<div className={`DeviceDeviceframecomponentsnavigation_DeviceDeviceframecomponentsnavigation ${props.className}`}>
		</div>
	)
}