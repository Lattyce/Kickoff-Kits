import React from 'react'
import './Property1Added.css'
import ShoppingCart_1 from "./ShoppingCart_1"
export default function Property1Added (props) {
	return (
		<div className={`Property1Added_Property1Added ${props.className}`}>
			<ShoppingCart_1 className='ShoppingCart'/>
		</div>
	)
}