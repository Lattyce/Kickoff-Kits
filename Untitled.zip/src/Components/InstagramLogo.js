import React from 'react'
import './InstagramLogo.css'
import ImgAsset from '../public'
export default function InstagramLogo (props) {
	return (
		<div className={`InstagramLogo_InstagramLogo ${props.className}`}>
			<img className='Vector' src = {ImgAsset.InstagramLogo_Vector} />
		</div>
	)
}