import React from 'react'
import './Pluginfilecover1.css'
export default function Pluginfilecover1 () {
	return (
		<div className='Pluginfilecover1_Pluginfilecover1'>
			<span className='KickoffKits'>Kickoff Kits</span>
		</div>
	)
}