import React from 'react'
import './Property1Default_7.css'
export default function Property1Default_7 (props) {
	return (
		<div className={`Property1Default_7_Property1Default ${props.className}`}>
			<span className='ShopNow'>Shop Now</span>
		</div>
	)
}