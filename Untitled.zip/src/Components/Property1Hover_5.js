import React from 'react'
import './Property1Hover_5.css'
export default function Property1Hover_5 (props) {
	return (
		<div className={`Property1Hover_5_Property1Hover ${props.className}`}>
			<span className='ShopNow'>Shop Now</span>
		</div>
	)
}