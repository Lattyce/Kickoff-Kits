import React from 'react'
import './Heart_1.css'
import ImgAsset from '../public'
export default function Heart_1 (props) {
	return (
		<div className={`Heart_1_Heart ${props.className}`}>
			<img className='Vector' src = {ImgAsset.Heart_1_Vector} />
		</div>
	)
}