import React from 'react'
import './nouncloset36947041.css'
import ImgAsset from '../public'
export default function Nouncloset36947041 (props) {
	return (
		<div className={`nouncloset36947041_nouncloset36947041 ${props.className}`}>
			<img className='Vector' src = {ImgAsset.nouncloset36947041_Vector} />
		</div>
	)
}