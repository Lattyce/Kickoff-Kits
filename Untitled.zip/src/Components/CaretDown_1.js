import React from 'react'
import './CaretDown_1.css'
import ImgAsset from '../public'
export default function CaretDown_1 (props) {
	return (
		<div className={`CaretDown_1_CaretDown ${props.className}`}>
			<img className='Vector' src = {ImgAsset.CaretDown_1_Vector} />
		</div>
	)
}