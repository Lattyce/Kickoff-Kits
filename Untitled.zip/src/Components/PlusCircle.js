import React from 'react'
import './PlusCircle.css'
import ImgAsset from '../public'
export default function PlusCircle (props) {
	return (
		<div className={`PlusCircle_PlusCircle ${props.className}`}>
			<img className='Vector' src = {ImgAsset.PlusCircle_Vector} />
		</div>
	)
}