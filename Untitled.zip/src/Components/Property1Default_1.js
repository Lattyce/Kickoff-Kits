import React from 'react'
import './Property1Default_1.css'
import Heart from "./Heart"
export default function Property1Default_1 (props) {
	return (
		<div className={`Property1Default_1_Property1Default ${props.className}`}>
			<Heart className='Heart'/>
		</div>
	)
}