import React from 'react'
import './Property1Pressed_1.css'
export default function Property1Pressed_1 (props) {
	return (
		<div className={`Property1Pressed_1_Property1Pressed ${props.className}`}>
			<span className='ShopNow'>Shop Now</span>
		</div>
	)
}