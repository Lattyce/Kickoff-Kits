import React from 'react'
import './Heart.css'
import ImgAsset from '../public'
export default function Heart (props) {
	return (
		<div className={`Heart_Heart ${props.className}`}>
			<img className='Vector' src = {ImgAsset.Heart_Vector} />
		</div>
	)
}