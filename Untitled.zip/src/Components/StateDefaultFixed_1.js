import React from 'react'
import './StateDefaultFixed_1.css'
import ButtonMain from "./ButtonMain"
export default function StateDefaultFixed_1 (props) {
	return (
		<div className={`StateDefaultFixed_1_StateDefaultFixed ${props.className}`}>
			<ButtonMain className='ButtonMain'/>
		</div>
	)
}