import React from 'react'
import './CaretLeft.css'
import ImgAsset from '../public'
export default function CaretLeft (props) {
	return (
		<div className={`CaretLeft_CaretLeft ${props.className}`}>
			<img className='Vector' src = {ImgAsset.CaretLeft_Vector} />
		</div>
	)
}