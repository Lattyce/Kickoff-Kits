import React from 'react'
import './FacebookLogo.css'
import ImgAsset from '../public'
export default function FacebookLogo (props) {
	return (
		<div className={`FacebookLogo_FacebookLogo ${props.className}`}>
			<img className='Vector' src = {ImgAsset.FacebookLogo_Vector} />
		</div>
	)
}