import React from 'react'
import './Property1Hover_8.css'
import Heart from "./Heart"
export default function Property1Hover_8 (props) {
	return (
		<div className={`Property1Hover_8_Property1Hover ${props.className}`}>
			<Heart className='Heart'/>
		</div>
	)
}