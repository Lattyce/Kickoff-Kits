import React from 'react'
import './MagnifyingGlass.css'
import ImgAsset from '../public'
export default function MagnifyingGlass (props) {
	return (
		<div className={`MagnifyingGlass_MagnifyingGlass ${props.className}`}>
			<img className='Vector' src = {ImgAsset.MagnifyingGlass_Vector} />
		</div>
	)
}