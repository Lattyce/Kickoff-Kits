import React from 'react'
import './List.css'
import ImgAsset from '../public'
export default function List (props) {
	return (
		<div className={`List_List ${props.className}`}>
			<img className='Vector' src = {ImgAsset.List_Vector} />
		</div>
	)
}