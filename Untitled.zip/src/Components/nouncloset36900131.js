import React from 'react'
import './nouncloset36900131.css'
import ImgAsset from '../public'
export default function Nouncloset36900131 (props) {
	return (
		<div className={`nouncloset36900131_nouncloset36900131 ${props.className}`}>
			<img className='Vector' src = {ImgAsset.nouncloset36900131_Vector} />
		</div>
	)
}